
OCR Ingest PoC
==============

Structure:
- server/: Node.js backend that performs OCR, calls LLM, stores results in SQLite, provides metrics & export.
- client/: Minimal React front-end (single-file App.js) demonstrating uploads and interaction.

See server/README_INSTALL.txt for setup steps.
