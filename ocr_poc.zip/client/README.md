
# OCR Ingest Client (PoC)

This is a minimal React app for demonstration. Steps:
1. Create-react-app or Vite recommended.
2. Place src/App.js into your React app.
3. Set REACT_APP_API_URL=http://localhost:3000 (or server host) in .env
4. `npm start` to run client (default port 3001 in package.json).
