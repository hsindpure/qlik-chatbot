import React, { useState, useEffect } from 'react';

const API = process.env.REACT_APP_API_URL || 'http://localhost:3000';

function App() {
  const [file, setFile] = useState(null);
  const [fieldsText, setFieldsText] = useState(''); // comma separated
  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState(null);
  const [jobId, setJobId] = useState(null);
  const [metrics, setMetrics] = useState({});
  const [failed, setFailed] = useState([]);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');

  useEffect(() => {
    fetchMetrics();
  }, []);

  async function fetchMetrics() {
    try {
      const r = await fetch(`${API}/api/metrics`);
      const j = await r.json();
      setMetrics(j);
    } catch (e) {
      console.error(e);
    }
  }

  async function fetchFailed() {
    try {
      const r = await fetch(`${API}/api/failed`);
      const j = await r.json();
      setFailed(j);
    } catch (e) {
      console.error(e);
    }
  }

  async function handleUpload(e) {
    e.preventDefault();
    if (!file) return alert('Choose file');
    setUploading(true);
    const form = new FormData();
    form.append('file', file);
    const fields = fieldsText.split(',').map(s => s.trim()).filter(Boolean);
    if (fields.length) form.append('fields', JSON.stringify(fields));
    else form.append('fields', '');
    try {
      const resp = await fetch(`${API}/api/upload`, { method: 'POST', body: form });
      const j = await resp.json();
      setResult(j.extracted);
      setJobId(j.jobId);
      await fetchMetrics();
    } catch (err) {
      console.error(err);
      alert('Upload failed: ' + (err.message || err));
    } finally {
      setUploading(false);
    }
  }

  async function handleExport() {
    if (!jobId) return alert('No job');
    window.open(`${API}/api/export/${jobId}`, '_blank');
  }

  async function askQuestion() {
    if (!jobId || !question) return alert('jobId + question required');
    try {
      const r = await fetch(`${API}/api/question`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jobId, question })
      });
      const j = await r.json();
      setAnswer(j.answer || j);
    } catch (e) {
      console.error(e);
      setAnswer('Error');
    }
  }

  return (
    <div style={{ fontFamily: 'Inter, Arial', maxWidth: 900, margin: '24px auto' }}>
      <h1>OCR Ingest PoC (local)</h1>

      <section style={{ border: '1px solid #eee', padding: 16, marginBottom: 12 }}>
        <h3>Upload (chat style)</h3>
        <form onSubmit={handleUpload}>
          <div>
            <input type="file" onChange={e => setFile(e.target.files[0])} />
          </div>
          <div style={{ marginTop: 8 }}>
            <label>Fields to extract (comma separated). Leave empty to auto-extract:</label>
            <br />
            <input
              style={{ width: '100%', padding: 8 }}
              value={fieldsText}
              onChange={e => setFieldsText(e.target.value)}
              placeholder="member_id, name, dob, address"
            />
          </div>
          <div style={{ marginTop: 8 }}>
            <button type="submit" disabled={uploading}>{uploading ? 'Uploading...' : 'Upload & Extract'}</button>
          </div>
        </form>
      </section>

      <section style={{ marginBottom: 12 }}>
        <h3>Result</h3>
        {result ? (
          <div>
            <pre style={{ whiteSpace: 'pre-wrap', background: '#fafafa', padding: 12 }}>
              {JSON.stringify(result, null, 2)}
            </pre>
            <div style={{ marginTop: 8 }}>
              <button onClick={handleExport}>Export CSV</button>
              <button onClick={fetchFailed} style={{ marginLeft: 8 }}>Show Failed Pages</button>
            </div>
          </div>
        ) : <div>No result yet</div>}
      </section>

      <section style={{ marginBottom: 12 }}>
        <h3>Ask a question about the document</h3>
        <input value={question} onChange={e => setQuestion(e.target.value)} placeholder="e.g. Which fields missing?" style={{ width: '70%', padding: 8 }} />
        <button onClick={askQuestion} style={{ marginLeft: 8 }}>Ask</button>
        {answer && <div style={{ marginTop: 8, background: '#f6f8fa', padding: 10 }}>{answer}</div>}
      </section>

      <section style={{ marginBottom: 12 }}>
        <h3>Monitoring</h3>
        <div>Total documents: {metrics.totalDocuments ?? 0} | Pages scanned: {metrics.totalPagesScanned ?? 0} | Failed pages: {metrics.totalFailedPages ?? 0}</div>
      </section>

      <section>
        <h3>Failed Pages</h3>
        <button onClick={fetchFailed}>Refresh</button>
        <ul>
          {failed.map(f => (
            <li key={f.id}>
              ID:{f.id} job:{f.jobId} page:{f.pageNumber} reason:{f.reason} resolved:{f.resolved}
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

export default App;