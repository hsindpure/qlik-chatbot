
Server setup (local):

1. Install system deps:
   - Ubuntu: sudo apt update && sudo apt install -y tesseract-ocr poppler-utils
   - MacOS: brew install tesseract poppler

2. Node setup:
   cd server
   npm install
   export LLM_API_URL=http://localhost:5001/llm   # or your internal LLM endpoint
   npm start

3. Open client app and set REACT_APP_API_URL to server host.
