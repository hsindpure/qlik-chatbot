// server.js - local OCR + LLM mapping PoC
const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const pdfParse = require('pdf-parse');
const tesseract = require('node-tesseract-ocr');
const child_process = require('child_process');
const Database = require('better-sqlite3');
const axios = require('axios');
const winston = require('winston');
const os = require('os');

// CONFIG (env vars)
const PORT = process.env.PORT || 3000;
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, 'data', 'uploads');
const PAGES_DIR = process.env.PAGES_DIR || path.join(__dirname, 'data', 'pages');
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data', 'db.sqlite');
const LLM_API_URL = process.env.LLM_API_URL || 'http://localhost:5001/llm'; // set by you
const LLM_API_KEY = process.env.LLM_API_KEY || ''; // optional

// ensure dirs
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
fs.mkdirSync(PAGES_DIR, { recursive: true });
fs.mkdirSync(path.join(__dirname, 'logs'), { recursive: true });

// logger
const logger = winston.createLogger({
  level: 'info',
  transports: [
    new winston.transports.File({ filename: path.join(__dirname,'logs','app.log') }),
    new winston.transports.Console()
  ]
});

// SQLite DB init
const db = new Database(DB_PATH);
db.exec(`
CREATE TABLE IF NOT EXISTS documents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  jobId TEXT UNIQUE,
  filename TEXT,
  createdAt TEXT,
  status TEXT,
  pagesScanned INTEGER,
  extractedJson TEXT,
  rawText TEXT,
  metricsJson TEXT
);
CREATE TABLE IF NOT EXISTS failed_pages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  jobId TEXT,
  pageNumber INTEGER,
  imagePath TEXT,
  reason TEXT,
  resolved INTEGER DEFAULT 0
);
`);

// multer config with 100MB limit
const upload = multer({
  dest: UPLOAD_DIR,
  limits: { fileSize: 100 * 1024 * 1024 } // 100MB
});

const app = express();
app.use(express.json({ limit: '2mb' }));

// Helper: Basic CSV generator (array of rows)
function toCSV(objArray) {
  const rows = Array.isArray(objArray) ? objArray : [objArray];
  if (rows.length === 0) return '';
  const keys = Object.keys(rows[0]);
  const lines = [keys.join(',')];
  for (const r of rows) {
    const vals = keys.map(k => (r[k] ?? '').toString().replace(/"/g, '""'));
    lines.push(vals.map(v => `"${v}"`).join(','));
  }
  return lines.join(os.EOL);
}

// Helper: detect if pdftoppm is available
function hasPdftoppm() {
  try {
    child_process.execSync('pdftoppm -v', { stdio: 'ignore' });
    return true;
  } catch (e) {
    return false;
  }
}

// convert PDF to PNG pages using pdftoppm (poppler)
function pdfToPngPages(pdfPath, outPrefix) {
  // outPrefix: full path prefix, e.g. /tmp/pages/page
  // produces outPrefix-1.png, -2.png ...
  return new Promise((resolve, reject) => {
    if (!hasPdftoppm()) {
      return reject(new Error('pdftoppm not installed. Install poppler-utils.'));
    }
    try {
      // -png -r 200 for better OCR
      child_process.execFileSync('pdftoppm', ['-png', '-r', '200', pdfPath, outPrefix]);
      // Find files created matching outPrefix-*.png
      const dir = path.dirname(outPrefix);
      const prefix = path.basename(outPrefix);
      const files = fs.readdirSync(dir)
        .filter(f => f.startsWith(prefix) && f.endsWith('.png'))
        .map(f => path.join(dir, f))
        .sort();
      resolve(files);
    } catch (err) {
      reject(err);
    }
  });
}

// OCR a single image with tesseract
async function ocrImage(imagePath) {
  const config = {
    lang: 'eng',
    oem: 1,
    psm: 3
  };
  try {
    const text = await tesseract.recognize(imagePath, config);
    return text;
  } catch (err) {
    logger.error('Tesseract error', err);
    throw err;
  }
}

// Call internal LLM API - generic wrapper
async function callLLM(promptPayload) {
  // promptPayload is object { prompt: string, ... } depending on your LLM API shape.
  try {
    const headers = { 'Content-Type': 'application/json' };
    if (LLM_API_KEY) headers['Authorization'] = `Bearer ${LLM_API_KEY}`;
    const resp = await axios.post(LLM_API_URL, promptPayload, { headers, timeout: 60000 });
    // Accept various response shapes: { text } or { choices: [{ text }] } or { result }
    if (resp.data == null) return null;
    if (resp.data.text) return resp.data.text;
    if (resp.data.choices && resp.data.choices[0] && resp.data.choices[0].text) return resp.data.choices[0].text;
    if (resp.data.result) return resp.data.result;
    return JSON.stringify(resp.data);
  } catch (err) {
    logger.error('LLM call failed', err.message || err);
    return null;
  }
}

// Build mapping prompt (string) for LLM wrapper
function buildMappingPrompt(ocrText, requestedFields) {
  const fieldsList = (Array.isArray(requestedFields) && requestedFields.length) ? requestedFields : [];
  const fieldsPart = fieldsList.length ? `FIELDS: ${JSON.stringify(fieldsList)}` : 'FIELDS: [] (extract whatever key-value you can)';
  const prompt = `
You are a data extraction assistant. Use the OCR text below to map values to requested fields, return JSON only.

${fieldsPart}

OCR_TEXT:
\`\`\`
${ocrText}
\`\`\`

Return JSON:
{
  "fields": { "<fieldname>": {"value":"...","confidence":0.0,"pages":[1],"raw_snippet":"..."} , ... },
  "data_quality": {"overall_quality":"good|medium|poor","notes":["..."] }
}
`;
  return { prompt };
}

// Upsert document record
function saveDocument(jobId, filename, status, pagesScanned, extractedJson, rawText, metricsJson) {
  const stmt = db.prepare(`
    INSERT OR REPLACE INTO documents (jobId, filename, createdAt, status, pagesScanned, extractedJson, rawText, metricsJson)
    VALUES (@jobId,@filename,@createdAt,@status,@pagesScanned,@extractedJson,@rawText,@metricsJson)
  `);
  stmt.run({
    jobId,
    filename,
    createdAt: new Date().toISOString(),
    status,
    pagesScanned,
    extractedJson: JSON.stringify(extractedJson || {}),
    rawText: rawText || '',
    metricsJson: JSON.stringify(metricsJson || {})
  });
}

// Save failed page
function recordFailedPage(jobId, pageNum, imagePath, reason) {
  const stmt = db.prepare('INSERT INTO failed_pages (jobId,pageNumber,imagePath,reason,resolved) VALUES (?,?,?,?,0)');
  stmt.run(jobId, pageNum, imagePath, reason);
}

// Metrics endpoint helper
function computeMetrics() {
  const docCountRow = db.prepare('SELECT COUNT(*) as c FROM documents').get();
  const pagesRow = db.prepare('SELECT IFNULL(SUM(pagesScanned),0) as pages FROM documents').get();
  const failedCountRow = db.prepare('SELECT COUNT(*) as c FROM failed_pages WHERE resolved=0').get();
  return {
    totalDocuments: docCountRow.c,
    totalPagesScanned: pagesRow.pages || 0,
    totalFailedPages: failedCountRow.c
  };
}

// Main API: upload and process
app.post('/api/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'file required' });
    const requestedFieldsRaw = req.body.fields || ''; // expected comma-separated or JSON
    let requestedFields = [];
    try {
      if (requestedFieldsRaw.trim().startsWith('[')) requestedFields = JSON.parse(requestedFieldsRaw);
      else requestedFields = requestedFieldsRaw.split(',').map(s => s.trim()).filter(Boolean);
    } catch (e) {
      requestedFields = requestedFieldsRaw.split(',').map(s => s.trim()).filter(Boolean);
    }

    const jobId = `job-${Date.now()}`;
    const savedPath = req.file.path;
    const origName = req.file.originalname;
    logger.info(`Received ${origName} as ${savedPath} with fields ${JSON.stringify(requestedFields)}`);

    // Try extracting text with pdf-parse if PDF
    let totalText = '';
    let pagesScanned = 0;
    let failedPages = [];

    if (req.file.mimetype === 'application/pdf' || path.extname(origName).toLowerCase() === '.pdf') {
      // try pdf-parse
      const dataBuffer = fs.readFileSync(savedPath);
      try {
        const pdfData = await pdfParse(dataBuffer);
        if (pdfData && pdfData.text && pdfData.text.trim().length > 40) {
          totalText = pdfData.text;
          pagesScanned = 1; // treat as single blob
          logger.info('pdf-parse extracted text (likely text-based PDF)');
        } else {
          // scanned PDF -> convert pages to images & OCR each
          const prefix = path.join(PAGES_DIR, `p_${jobId}`);
          try {
            const pageFiles = await pdfToPngPages(savedPath, prefix);
            pagesScanned = pageFiles.length;
            const pageTexts = [];
            for (let i = 0; i < pageFiles.length; i++) {
              const imagePath = pageFiles[i];
              try {
                const txt = await ocrImage(imagePath);
                pageTexts.push(`---PAGE ${i+1}---\n${txt}`);
              } catch (err) {
                failedPages.push({ page: i+1, path: imagePath, reason: err.message });
                recordFailedPage(jobId, i+1, imagePath, err.message);
              }
            }
            totalText = pageTexts.join('\n');
          } catch (err) {
            logger.error('pdf->png conversion failed: ' + err.message);
            // fallback: try pdf-parse text only (even if blank)
            totalText = pdfData.text || '';
            pagesScanned = 1;
          }
        }
      } catch (err) {
        logger.error('pdf-parse error: ' + err.message);
        // fallback to OCR approach only: convert to images if possible
        try {
          const prefix = path.join(PAGES_DIR, `p_${jobId}`);
          const pageFiles = await pdfToPngPages(savedPath, prefix);
          pagesScanned = pageFiles.length;
          const pageTexts = [];
          for (let i = 0; i < pageFiles.length; i++) {
            const imagePath = pageFiles[i];
            try {
              const txt = await ocrImage(imagePath);
              pageTexts.push(`---PAGE ${i+1}---\n${txt}`);
            } catch (err) {
              failedPages.push({ page: i+1, path: imagePath, reason: err.message });
              recordFailedPage(jobId, i+1, imagePath, err.message);
            }
          }
          totalText = pageTexts.join('\n');
        } catch (err2) {
          totalText = '';
          pagesScanned = 0;
        }
      }
    } else {
      // image -> OCR directly
      try {
        const txt = await ocrImage(savedPath);
        totalText = txt;
        pagesScanned = 1;
      } catch (err) {
        logger.error('image OCR failed: ' + err.message);
        recordFailedPage(jobId, 1, savedPath, err.message);
        failedPages.push({ page: 1, path: savedPath, reason: err.message });
      }
    }

    // Build LLM prompt for mapping
    const mappingPrompt = buildMappingPrompt(totalText, requestedFields);
    const llmResponse = await callLLM(mappingPrompt); // may be null if LLM unreachable
    let extractedJson = {};
    if (llmResponse) {
      // Try parse JSON if returned JSON string
      try {
        const parsed = (typeof llmResponse === 'string') ? JSON.parse(llmResponse) : llmResponse;
        extractedJson = parsed;
      } catch (err) {
        // If LLM returned text but not JSON, wrap into a field
        extractedJson = { raw_llm_output: llmResponse };
      }
    } else {
      // No LLM: do simple regex heuristic extraction for requested fields
      extractedJson = { fields: {}, data_quality: { overall_quality: 'poor', notes: ['LLM call failed; heuristic fallback used'] } };
      const heuristics = {
        email: /([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/,
        phone: /(\+?\d{7,15})/,
        date: /(\d{1,2}[-\/]\d{1,2}[-\/]\d{2,4})/,
        id: /([A-Z0-9\-]{6,20})/
      };
      for (const f of requestedFields) {
        const rx = heuristics[f.toLowerCase()] || null;
        let found = null;
        if (rx) {
          const m = totalText.match(rx);
          if (m) found = m[0];
        }
        extractedJson.fields[f] = { value: found, confidence: found ? 0.6 : 0.0, pages: [] , raw_snippet: found ? found : '' };
      }
    }

    // prepare metrics
    const metrics = {
      pagesScanned,
      extractedFieldsCount: extractedJson.fields ? Object.keys(extractedJson.fields).length : 0,
      failedPagesCount: failedPages.length
    };

    // save to DB
    saveDocument(jobId, origName, 'completed', pagesScanned, extractedJson, totalText, metrics);

    // return result
    return res.json({
      jobId,
      filename: origName,
      status: 'completed',
      pagesScanned,
      extracted: extractedJson,
      metrics
    });

  } catch (err) {
    logger.error('Processing error: ' + (err && err.stack ? err.stack : err));
    return res.status(500).json({ error: 'server error', message: err.message });
  }
});

// Get document by jobId
app.get('/api/document/:jobId', (req, res) => {
  const jobId = req.params.jobId;
  const row = db.prepare('SELECT * FROM documents WHERE jobId = ?').get(jobId);
  if (!row) return res.status(404).json({ error: 'not found' });
  row.extractedJson = JSON.parse(row.extractedJson || '{}');
  row.metricsJson = JSON.parse(row.metricsJson || '{}');
  return res.json(row);
});

// Export CSV for job
app.get('/api/export/:jobId', (req, res) => {
  const jobId = req.params.jobId;
  const row = db.prepare('SELECT * FROM documents WHERE jobId = ?').get(jobId);
  if (!row) return res.status(404).send('not found');
  const extracted = JSON.parse(row.extractedJson || '{}');
  // Build a single row CSV from field values (fields -> columns)
  const fields = extracted.fields || {};
  const csvObj = {};
  for (const k of Object.keys(fields)) {
    csvObj[k] = fields[k].value ?? '';
  }
  const csv = toCSV([csvObj]);
  res.setHeader('Content-Disposition', `attachment; filename="${jobId}.csv"`);
  res.setHeader('Content-Type', 'text/csv');
  return res.send(csv);
});

// metrics
app.get('/api/metrics', (req, res) => {
  res.json(computeMetrics());
});

// failed pages list
app.get('/api/failed', (req, res) => {
  const rows = db.prepare('SELECT * FROM failed_pages WHERE resolved=0').all();
  res.json(rows);
});

// manual resolve API
app.post('/api/failed/resolve', (req, res) => {
  const { id, correctedText } = req.body;
  if (!id) return res.status(400).json({ error: 'id required' });
  const row = db.prepare('SELECT * FROM failed_pages WHERE id = ?').get(id);
  if (!row) return res.status(404).json({ error: 'not found' });
  // Mark resolved and store corrected text into a doc update (very simple)
  db.prepare('UPDATE failed_pages SET resolved=1 WHERE id = ?').run(id);
  // Optionally append correctedText to the document rawText and re-run mapping - left for next iteration
  return res.json({ status: 'ok' });
});

// Q&A endpoint: client asks a question about document
app.post('/api/question', async (req, res) => {
  const { jobId, question } = req.body;
  if (!jobId || !question) return res.status(400).json({ error: 'jobId and question required' });
  const row = db.prepare('SELECT * FROM documents WHERE jobId = ?').get(jobId);
  if (!row) return res.status(404).json({ error: 'document not found' });
  const extracted = JSON.parse(row.extractedJson || '{}');
  const prompt = `
We have this structured data JSON:
${JSON.stringify(extracted, null, 2)}

User question:
"${question}"

Answer concisely based only on the JSON. If not determinable, say "cannot determine from provided data".
`;
  const resp = await callLLM({ prompt });
  return res.json({ answer: resp });
});

app.listen(PORT, () => {
  logger.info(`Server started on http://localhost:${PORT}`);
  logger.info(`Uploads dir: ${UPLOAD_DIR}`);
});